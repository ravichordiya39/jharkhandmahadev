<?php 
 require_once './jkmadmin/config/config.php';
 include_once './functions.php';
?>